# KPP HOA Website — Starter Package

This is a static front-end prototype for the KPP HOA public website and demo admin dashboard.

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge, Firefox, or another browser.
3. Select **Admin Portal** to view the demo dashboard.

Demo credentials:
- Username: `admin`
- Password: `KPPdemo2026`

## Publish using Vercel (static website)
1. Create/sign in to a Vercel account.
2. Create a GitHub repository and upload `index.html` to the repository root.
3. In Vercel, choose **Add New → Project**, import that repository, and deploy.
4. No build command or framework preset is needed for this plain HTML starter.
5. Vercel will provide a temporary `*.vercel.app` URL. A custom domain can be connected later.

Alternative: upload the extracted folder to a static hosting service that supports drag-and-drop deployment.

## Important limitations — do not use for real HOA records yet
- This is a front-end demonstration, not a production HOA management system.
- The demo login credentials are visible in the JavaScript source and provide no real security.
- Requests, members and announcements exist only in browser memory and are lost when the page is refreshed.
- There is no database, server, email/SMS notification, real authentication, access control, audit log, or backup.
- Do not enter real homeowner personal data, IDs, contact details, payment details, or confidential financial records.
- Before collecting actual data, connect a backend (for example Supabase) with server-side authentication, role-based permissions, Row Level Security, audit logs, backups, and a privacy notice/consent process appropriate to the Data Privacy Act of 2012.

## Before public launch
Verify the association's exact registered name, registration number, office address, contact details, officer list, approved mission/vision, current masterlist statistics, and all published policies. The sample masterlist count of 396 is marked as a reference figure and should be confirmed before publication.
